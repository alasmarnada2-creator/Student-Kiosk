﻿namespace StudentSuplier.Models
{
    public class CartListViewModel
    {
        public List<CartViewModel> carts { get; set; }
        public List<Product> products { get; set; }
    }
}
