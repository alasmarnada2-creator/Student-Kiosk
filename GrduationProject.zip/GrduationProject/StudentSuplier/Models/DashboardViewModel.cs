﻿namespace StudentSuplier.Models
{
    public class DashboardViewModel
    {
        public List<Product> Products { get; set; }
        public List<Order> Orders { get; set; }
    }

}
